﻿function preventDefault(event) {
    if (event && event.preventDefault) {
        event.preventDefault();
    }
}
document.addEventListener('dragover', (event) => {
    event.preventDefault();
});
