﻿namespace TaskAPP.Models
{
    public class UserModel
    {
        public int user_id { get; set; } 
        public string ?email { get; set; }
        public string ?name { get; set; }
       
    }
}
