﻿namespace TaskAPP.Models
{
    public class NotificationModel
    {
        public int TaskId { get; set; }
        public string Message
        {
            get; set;
        } = "Task Updated";

    }
}
