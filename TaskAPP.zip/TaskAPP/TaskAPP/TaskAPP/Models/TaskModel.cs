﻿using System.ComponentModel.DataAnnotations;


namespace TaskAPP.Models
{
    public class TaskModel
    {
        
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter Valid Title")]
        public string ?Title { get; set; }

        public int Status { get; set; } = 0;

        // 0 => Not started , 1=> Complete , 2=> Progress

        [Required(ErrorMessage = "Select Name for Assign TAsk")]
        public string ?AssignTo { get; set; }

    }


}
