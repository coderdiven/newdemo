﻿using Microsoft.AspNetCore.SignalR;
using TaskAPP.Models;
using TaskAPP.Services;

namespace TaskAPP.Hubs
{
    public class TaskHub : Hub
    {

        private readonly TaskService _taskService;

        public TaskHub(TaskService taskService)
        {
            _taskService = taskService;
        }
        public async Task NotifyStatusUpdate(int Taskid)
        {
            var tasks = await _taskService.GetAllTasks();
            await Clients.All.SendAsync("TaskUpdated",Taskid,tasks);
        }

        public async Task AssignTaskToUser(TaskModel model)
        {
             await _taskService.AddTaskAsync(model);
            await Clients.All.SendAsync("TaskAdded", model);
        }
    }
}
