﻿using System.Text.Json;
using TaskAPP.Models;

namespace TaskAPP.Services
{
    public class TaskService
    {
        private readonly string filepath;
        private  string userpath;
        public TaskService()
        {
            filepath = Path.Combine(Directory.GetCurrentDirectory(),"data","task.json");
        }

        public async Task<List<TaskModel>> GetAllTasks()
        {
            if(!File.Exists(filepath))
            {
                return new List<TaskModel>();
            }
            else
            {
                var json = File.ReadAllText(filepath); // Reading entrire file as a string
                
                var list= JsonSerializer.Deserialize<List<TaskModel>>(json); // convert json string into list of taskmodel objcets
                
                return list ?? new List<TaskModel>();
            }
            

        }

        public async Task UpdateStatus(int TaskId,int NewStatus)
        {
            var tasks= await GetAllTasks();
            var task = tasks.Find(t => t.Id == TaskId);

            if(task==null)
            {
                throw new Exception("Old Status is not Matching");
            }
            else
            {
                task.Status = NewStatus;
                await SaveTask(tasks);
            }
        }

        public async Task SaveTask(List<TaskModel> tasks)
        {
            // it is use for givinig proper format in json file 
            var options = new JsonSerializerOptions
            {
                WriteIndented = true
            };

            var json = JsonSerializer.Serialize(tasks, options);
            await File.WriteAllTextAsync(filepath, json);
        }

        public async Task<List<UserModel>> GetAllUser()
        {
            userpath = Path.Combine(Directory.GetCurrentDirectory(), "data", "User.json");
            if (!File.Exists(userpath))
            {
                return new List<UserModel>();
            }
            try
            { 

                var json = File.ReadAllText(userpath); // Reading entrire file as a string

                var list = JsonSerializer.Deserialize<List<UserModel>>(json); // convert json string into list of taskmodel objcets

                return list ?? new List<UserModel>();
            }
            catch (IOException e)
            {
                Console.WriteLine("Error reading file: " + e.Message);
                return new List<UserModel>();
            }
         
            


        }

        public async Task AddTaskAsync(TaskModel taskModel)
        {
            var tasks=await GetAllTasks();

            int newid = tasks.Any() ? tasks.Max(t => t.Id) + 1 : 1;

            taskModel.Id = newid;
            tasks.Add(taskModel);
            await SaveTask(tasks);  
        }

    }
}
